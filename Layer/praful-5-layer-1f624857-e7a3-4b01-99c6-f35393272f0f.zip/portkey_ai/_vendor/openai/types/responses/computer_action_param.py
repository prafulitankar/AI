# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Iterable, Optional
from typing_extensions import Literal, Required, TypeAlias, TypedDict

from ..._types import SequenceNotStr

__all__ = [
    "ComputerActionParam",
    "Click",
    "DoubleClick",
    "Drag",
    "DragPath",
    "Keypress",
    "Move",
    "Screenshot",
    "Scroll",
    "Type",
    "Wait",
]


class Click(TypedDict, total=False):
    """A click action."""

    button: Required[Literal["left", "right", "wheel", "back", "forward"]]
    """Indicates which mouse button was pressed during the click.

    One of `left`, `right`, `wheel`, `back`, or `forward`.
    """

    type: Required[Literal["click"]]
    """Specifies the event type. For a click action, this property is always `click`."""

    x: Required[int]
    """The x-coordinate where the click occurred."""

    y: Required[int]
    """The y-coordinate where the click occurred."""

    keys: Optional[SequenceNotStr[str]]
    """The keys being held while clicking."""


class DoubleClick(TypedDict, total=False):
    """A double click action."""

    keys: Required[Optional[SequenceNotStr[str]]]
    """The keys being held while double-clicking."""

    type: Required[Literal["double_click"]]
    """Specifies the event type.

    For a double click action, this property is always set to `double_click`.
    """

    x: Required[int]
    """The x-coordinate where the double click occurred."""

    y: Required[int]
    """The y-coordinate where the double click occurred."""


class DragPath(TypedDict, total=False):
    """An x/y coordinate pair, e.g. `{ x: 100, y: 200 }`."""

    x: Required[int]
    """The x-coordinate."""

    y: Required[int]
    """The y-coordinate."""


class Drag(TypedDict, total=False):
    """A drag action."""

    path: Required[Iterable[DragPath]]
    """An array of coordinates representing the path of the drag action.

    Coordinates will appear as an array of objects, eg

    ```
    [
      { x: 100, y: 200 },
      { x: 200, y: 300 }
    ]
    ```
    """

    type: Required[Literal["drag"]]
    """Specifies the event type.

    For a drag action, this property is always set to `drag`.
    """

    keys: Optional[SequenceNotStr[str]]
    """The keys being held while dragging the mouse."""


class Keypress(TypedDict, total=False):
    """A collection of keypresses the model would like to perform."""

    keys: Required[SequenceNotStr[str]]
    """The combination of keys the model is requesting to be pressed.

    This is an array of strings, each representing a key.
    """

    type: Required[Literal["keypress"]]
    """Specifies the event type.

    For a keypress action, this property is always set to `keypress`.
    """


class Move(TypedDict, total=False):
    """A mouse move action."""

    type: Required[Literal["move"]]
    """Specifies the event type.

    For a move action, this property is always set to `move`.
    """

    x: Required[int]
    """The x-coordinate to move to."""

    y: Required[int]
    """The y-coordinate to move to."""

    keys: Optional[SequenceNotStr[str]]
    """The keys being held while moving the mouse."""


class Screenshot(TypedDict, total=False):
    """A screenshot action."""

    type: Required[Literal["screenshot"]]
    """Specifies the event type.

    For a screenshot action, this property is always set to `screenshot`.
    """


class Scroll(TypedDict, total=False):
    """A scroll action."""

    scroll_x: Required[int]
    """The horizontal scroll distance."""

    scroll_y: Required[int]
    """The vertical scroll distance."""

    type: Required[Literal["scroll"]]
    """Specifies the event type.

    For a scroll action, this property is always set to `scroll`.
    """

    x: Required[int]
    """The x-coordinate where the scroll occurred."""

    y: Required[int]
    """The y-coordinate where the scroll occurred."""

    keys: Optional[SequenceNotStr[str]]
    """The keys being held while scrolling."""


class Type(TypedDict, total=False):
    """An action to type in text."""

    text: Required[str]
    """The text to type."""

    type: Required[Literal["type"]]
    """Specifies the event type.

    For a type action, this property is always set to `type`.
    """


class Wait(TypedDict, total=False):
    """A wait action."""

    type: Required[Literal["wait"]]
    """Specifies the event type.

    For a wait action, this property is always set to `wait`.
    """


ComputerActionParam: TypeAlias = Union[Click, DoubleClick, Drag, Keypress, Move, Screenshot, Scroll, Type, Wait]
