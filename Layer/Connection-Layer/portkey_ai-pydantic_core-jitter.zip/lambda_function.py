import os
from portkey_ai import Portkey
import pydantic
import pydantic_core

def lambda_handler(event, context):
    return {
        "pydantic": pydantic.__version__,
        "pydantic_core": pydantic_core.__version__,
    }

def lambda_handler(event, context):
    # Load API key from environment variable
    portkey_api_key = os.environ.get("PORTKEY_API_KEY")

    # Initialize Portkey client
    portkey = Portkey(
        base_url="https://portkeygateway.perficient.com/v1",
        api_key=portkey_api_key
    )

    # Extract user prompt dynamically from event
    prompt_text = event.get("prompt", "Default prompt")

    try:
        # Call Anthropic Claude Opus model via Portkey
        response = portkey.chat.completions.create(
            model="@aws-bedrock-use2/us.anthropic.claude-opus-4-6-v1",  # Portkey model alias
            messages=[
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": prompt_text}
            ],
            max_tokens=512,   # lowercase, correct parameter
            temperature=0.7
        )

        # Debug: log raw response to CloudWatch
        print("Portkey raw response:", response)

        # Return the model output
        return {
            "statusCode": 200,
            "body": response.choices[0].message.content
        }

    except Exception as e:
        print("Error:", str(e))
        return {
            "statusCode": 500,
            "body": f"Error: {str(e)}"
        }

